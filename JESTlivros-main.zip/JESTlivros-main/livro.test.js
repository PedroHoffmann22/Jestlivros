const { adicionarLivro, buscarLivro, removerLivro } = require('./test')

test("adicionar livro funciona", () => {
    const entrada = { titulo: 'Diário de um Banana', autor: 'Jeff Kinney', anoPublicacao: 2007 }
    const resposta = [
        { titulo: 'Diário de um Banana: Rodrick é o Cara', autor: 'Jeff Kinney', anoPublicacao: 2008 },
        { titulo: 'Diário de um Banana: A Gota DÁgua', autor: 'Jeff Kinney', anoPublicacao: 2009 },
        { titulo: 'Diário de um Banana: Dias de Cão', autor: 'Jeff Kinney', anoPublicacao: 2009 },
        { titulo: 'Diário de um Banana', autor: 'Jeff Kinney', anoPublicacao: 2007 }
    ]
    expect(adicionarLivro(entrada)).toEqual(resposta)
})

test("erro quando o formato da variavel for errado", () => {
    const livro1 = { titulo: 'Diário de um Banana', autor: 'Jeff Kinney', anoPublicacao: 2007 };
    const livro2 = { titulo: 'Diário de um Banana', autor: 'Diário de um Banana', anoPublicacao: 2007 };
    const livro3 = { titulo: 'Diário de um Banana', autor: 'Jeff Kinney', anoPublicacao: '2007' };
    expect(() => adicionarLivro(livro1)).toThrow()
    expect(() => adicionarLivro(livro2)).toThrow()
    expect(() => adicionarLivro(livro3)).toThrow()
}) 

test("erro quando for um livro já disponivel no acervo", () => {
    const entrada = { titulo: 'Diário de um Banana: Rodrick é o Cara', autor: 'Jeff Kinney', anoPublicacao: 2008 }
    expect(() => adicionarLivro(entrada)).toThrow()
})

test("buscar livro funciona", () => {
    const entrada = "Diário de um Banana: Rodrick é o Cara"
    const resposta = { titulo: 'Diário de um Banana: Rodrick é o Cara', autor: 'Jeff Kinney', anoPublicacao: 2008 }
    expect(buscarLivro(entrada)).toEqual(resposta)
})

test("titulo começando com letra minuscula", () => {
    const entrada = 'Diário de um Banana: A Gota DÁgua'
    expect(buscarLivro(entrada)).toEqual({ titulo: 'Diário de um Banana: A Gota DÁgua', autor: 'Jeff Kinney', anoPublicacao: 2009 })
})

test("buscar livro não disponivel no acervo", () => {
    const entrada = 'Pai rico Pai pobre'
    expect(() => buscarLivro(entrada)).toThrow()
})

test("remover livro funciona", () => {
    const entrada = 'Diário de um Banana: Dias de Cão'
    const resposta = [
        { titulo: 'Diário de um Banana: Rodrick é o Cara', autor: 'Jeff Kinney', anoPublicacao: 2008 },
        { titulo: 'Diário de um Banana: A Gota DÁgua', autor: 'Jeff Kinney', anoPublicacao: 2009 },
        { titulo: 'Diário de um Banana', autor: 'Jeff Kinney', anoPublicacao: 2007 }
    ]
    expect(removerLivro(entrada)).toEqual(resposta) 
})

test("titulo começando com letra minuscula", () => {
    const entrada = 'Diário de um Banana: Rodrick é o Cara'
    const resposta = [
        { titulo: 'Diário de um Banana: A Gota DÁgua', autor: 'Jeff Kinney', anoPublicacao: 2009 },
        { titulo: 'Diário de um Banana', autor: 'Jeff Kinney', anoPublicacao: 2007 }
    ]
    expect(removerLivro(entrada)).toEqual(resposta)
})

test("remover livro não disponivel no acervo", () => {
    const entrada = 'EU FICO LOKO'
    expect(() => removerLivro(entrada)).toThrow()
})