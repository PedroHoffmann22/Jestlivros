const livro = { titulo: 'Pai rico Pai pobre', autor: ' Robert Kiyosaki, Sharon L. Lechter', anoPublicacao: 1997 };
const livro2 = { titulo: 'Diário de um Banana: Rodrick é o Cara', autor: 'Jeff Kinney', anoPublicacao: 2008 };

var livros = [
    { titulo: 'Diário de um Banana: Rodrick é o Cara', autor: 'Jeff Kinney', anoPublicacao: 2008 },
    { titulo: 'Diário de um Banana: A Gota DÁgua', autor: 'Jeff Kinney', anoPublicacao: 2009 },
    { titulo: 'Diário de um Banana: Dias de Cão', autor: 'Jeff Kinney', anoPublicacao: 2009 }
]


function adicionarLivro(livro) {
    const tituloTeste = livro.titulo.toString()
    const autorTeste = livro.autor.toString()
    const anoTeste = Number(livro.anoPublicacao)
    for(i=0; i < livros.length; i++){
        if(livros[i].titulo === livro.titulo){
            throw new Error(`o livro ${livro.titulo} já esta disponivel no acervo`)
        }
    }
    if (livro.titulo === tituloTeste && livro.autor === autorTeste && livro.anoPublicacao === anoTeste) {
        livros.push(livro)
    } else {
        throw new Error(`Não foi possivel adicionar o livro ${livro.titulo}`)
    }

    return livros
}
//console.log(adicionarLivro(livro))

function buscarLivro(titulo) {
    titulo = titulo.toLowerCase()
    for (let i = 0; i < livros.length; i++) {
        if (livros[i].titulo.toLocaleLowerCase() === titulo) {
            return livros[i];
        }
    }
    throw new Error(`O livro ${titulo} não foi encontrado no arcevo`);
}
console.log(buscarLivro('duna'))

function removerLivro(titulo) {
    titulo = titulo.toLowerCase()
    for (let i = 0; i < livros.length; i++) {
        if (livros[i].titulo.toLocaleLowerCase() === titulo) {
            livros.splice(i, 1)
            return livros
        }

    }
    throw new Error(`O livro ${titulo} não foi encontrado no acervo`);
}


module.exports = {adicionarLivro, buscarLivro, removerLivro}